<?php
/**
 * Created by PhpStorm.
 * User: hamed
 * Date: 3/1/18
 * Time: 10:44 AM
 */
require_once('SmsHelper.php');

SmsHelper::send('989155190327', 'این پیام آزمایشی است.');