<?php
//update:1392-05-13
require_once('lib/nusoap.php');
include_once('messages.php');
//WEB SERVICE PARAMETERS
$sms_url='http://sms.3300.ir/almassms.asmx?wsdl';//Web Service URL
$sms_username = 'user'; //Web Service Username
$sms_password = 'pass'; //Web Service Password
//WEB SERVICE INIT------------------------------------------------------------
$client = new nusoap_client($sms_url, 'wsdl', '', '', '', '');
if ($client->fault) {
    trigger_error("SOAP Fault: (faultcode: {$result->faultcode}, faultstring: {$result->faulstring})", E_ERROR);
} else {
    // Check for errors
    $err = $client->getError();
    if ($err) {
        // Display the error
        echo '<h2>Error</h2><pre>' . $err . '</pre>';
    }
}
//WEB SERVICE INIT-------------------------------------------------------------
		$result = $client->call('GetCredit', array(
			'pUsername' => $sms_username,
			'pPassword' => $sms_password
		));
		//echo var_dump($result);
 if ($result['GetCreditResult'] < 0)  
	{
	echo 'Method executed successfully without any errors'.'<br/>';
	echo 'Credit : ' . $result['pCredit'].' Rials' ;
	}
else
	{
	echo 'Method execution failed'.'<br/>';
	echo $METHOD_errors[$result['GetCreditResult']]['title'];
	}
	?>

