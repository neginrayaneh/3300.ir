<?php
/**
 * راهنمای ارسال پیامک با rest api پنل پیامک نگین
 * برای مشاهده فایل راهنما به سایت http://3300.ir/#webservice مراجعه کنید
 */
require_once('SmsHelper.php');

SmsHelper::send('989395213300', 'تست.');
